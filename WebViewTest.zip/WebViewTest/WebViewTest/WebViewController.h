//
//  WebViewController.h
//  WebViewTest
//
//  Created by 怒煮西兰花 on 16/6/13.
//  Copyright © 2016年 mistong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WebViewJavascriptBridge.h"
#import "RedViewController.h"
#import "GreenViewController.h"
#import "BlueViewController.h"
#import "CyanViewController.h"
@interface WebViewController : UIViewController
@property (nonnull,strong)WebViewJavascriptBridge *bridge;
@property (nonatomic,strong)UIWebView *webView;
@property (nonatomic,copy)NSString *urlStr;
@end

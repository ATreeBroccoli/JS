//
//  GreenViewController.h
//  WebViewTest
//
//  Created by 怒煮西兰花 on 16/6/13.
//  Copyright © 2016年 mistong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GreenViewController : UIViewController

@end

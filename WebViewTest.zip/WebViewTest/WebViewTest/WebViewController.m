//
//  WebViewController.m
//  WebViewTest
//
//  Created by 怒煮西兰花 on 16/6/13.
//  Copyright © 2016年 mistong. All rights reserved.
//

#import "WebViewController.h"

@interface WebViewController ()<UIWebViewDelegate>

@end

@implementation WebViewController

- (UIWebView *)webView{
    if(_webView == nil){
        self.webView = [[UIWebView alloc] init];
    }
    return _webView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//    if (self.urlStr == nil) {
//        return;
//    }
    
    [self.view addSubview:self.webView];
    self.webView.frame = self.view.bounds;
    self.webView.backgroundColor = [UIColor redColor];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:self.urlStr]];
    [self.webView loadRequest:request];
    
    self.webView.delegate = self;
    
    
    //创建桥 用来进行从JS代码那里获取 信息
    self.bridge = [WebViewJavascriptBridge bridgeForWebView:_webView handler:^(id data, WVJBResponseCallback responseCallback) {
//        NSLog(@"Received message from javascript: %@", data);
        if ([data isEqual:@"red"]) {
            self.navigationController.tabBarController.selectedIndex = 0;
            [self.navigationController popViewControllerAnimated:NO];
            
            
        } else if([data isEqual:@"green"]){
            self.navigationController.tabBarController.selectedIndex = 1;
            [self.navigationController popViewControllerAnimated:NO];
            
            
        }else if ([data isEqual:@"blue"]){
            self.navigationController.tabBarController.selectedIndex = 2;
            [self.navigationController popViewControllerAnimated:NO];
            
        }else if([data isEqual:@"cyan"]){
            [self.navigationController popViewControllerAnimated:NO];
        }
      
    }];
    
    //发送信息
    [self.bridge send:@"Well hello there"];
    
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    NSString *jsStr = @"var redBt = document.getElementById('red');redBt.onclick=function(){}";
    [webView stringByEvaluatingJavaScriptFromString:jsStr];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    NSLog(@"加载失败:%@",error);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
